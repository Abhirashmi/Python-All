l = [str(i*7) for i in range(1, 11)]
print(l)

verticalTable = "\n".join(l)
print(verticalTable)