story = "Harry is good.\nHe\tis ve\\ry good"
print(story)